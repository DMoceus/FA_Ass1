
package bugModel.results;

public class Results implements Display, FileLog {


} // end public class Results


