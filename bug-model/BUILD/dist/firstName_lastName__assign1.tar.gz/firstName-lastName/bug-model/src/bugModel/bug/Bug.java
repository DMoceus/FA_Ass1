package bugModel.bug;

public class Bug implements AllDirectionsBug {

    public String toString() {
	String retValue = "\n I am a 2015 Volkswagen Bettle Convertible \n";
	return retValue;
    }

}