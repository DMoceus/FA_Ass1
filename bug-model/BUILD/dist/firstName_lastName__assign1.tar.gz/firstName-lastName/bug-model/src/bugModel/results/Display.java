package bugModel.results;

public interface Display {
    // add appropriate method

} 
