package bugModel.bug;

public interface AllDirectionsBug {

    // methods to move right, left, up, down

}