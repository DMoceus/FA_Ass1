package bugModel.results;

public interface FileLog {
    // add appropriate method 

} 
